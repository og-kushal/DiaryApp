package com.example.diaryapp

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete
import androidx.room.Update

@Dao
interface DiaryDao {

    @Insert
    suspend fun insert(entry: DiaryEntry)

    @Update
    suspend fun update(entry: DiaryEntry)

    @Delete
    suspend fun delete(entry: DiaryEntry)

    @Query("SELECT * FROM diary_table ORDER BY id DESC")
    suspend fun getAllEntries(): List<DiaryEntry>

    @Query("SELECT * FROM diary_table WHERE text LIKE '%' || :query || '%' ORDER BY id DESC")
    suspend fun searchEntries(query: String): List<DiaryEntry>

    @Query("SELECT * FROM diary_table WHERE date = :selectedDate ORDER BY id DESC")
    suspend fun filterByDate(selectedDate: String): List<DiaryEntry>
}
