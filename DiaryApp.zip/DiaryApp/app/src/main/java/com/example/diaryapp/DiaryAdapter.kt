package com.example.diaryapp

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DiaryAdapter(
    private var entries: List<DiaryEntry>,
    private val onDeleteClick: (DiaryEntry) -> Unit,
    private val onViewClick: (DiaryEntry) -> Unit
) : RecyclerView.Adapter<DiaryAdapter.DiaryViewHolder>() {

    class DiaryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val date: TextView = itemView.findViewById(R.id.itemDate)
        val text: TextView = itemView.findViewById(R.id.itemText)
        val photo: ImageView = itemView.findViewById(R.id.itemPhoto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DiaryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_diary_entry, parent, false)
        return DiaryViewHolder(view)
    }

    override fun onBindViewHolder(holder: DiaryViewHolder, position: Int) {
        val entry = entries[position]

        holder.date.text = entry.date
        holder.text.text = entry.text

        // -------------------------
        // LOAD PHOTO IF AVAILABLE
        // -------------------------
        if (entry.photoUri != null) {
            holder.photo.visibility = View.VISIBLE
            holder.photo.setImageURI(Uri.parse(entry.photoUri))
        } else {
            holder.photo.visibility = View.GONE
        }

        // -------------------------
        // CLICK TO VIEW ENTRY
        // -------------------------
        holder.itemView.setOnClickListener {
            onViewClick(entry)
        }

        // -------------------------
        // LONG PRESS = DELETE
        // -------------------------
        holder.itemView.setOnLongClickListener {
            onDeleteClick(entry)
            true
        }
    }

    override fun getItemCount(): Int = entries.size

    fun updateData(newEntries: List<DiaryEntry>) {
        entries = newEntries
        notifyDataSetChanged()
    }
}
