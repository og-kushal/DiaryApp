package com.example.diaryapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DisplayFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DiaryAdapter
    private lateinit var db: DiaryDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_display, container, false)

        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        db = DiaryDatabase.getDatabase(requireContext())

        loadEntries()

        return view
    }

    private fun loadEntries() {
        CoroutineScope(Dispatchers.IO).launch {
            val entries = db.diaryDao().getAllEntries()

            CoroutineScope(Dispatchers.Main).launch {
                adapter = DiaryAdapter(
                    entries,
                    onDeleteClick = { entry ->
                        deleteEntry(entry)
                    },
                    onViewClick = { entry ->
                        viewEntry(entry)
                    }
                )

                recyclerView.adapter = adapter
            }
        }
    }

    private fun deleteEntry(entry: DiaryEntry) {
        CoroutineScope(Dispatchers.IO).launch {
            db.diaryDao().delete(entry)
            val updated = db.diaryDao().getAllEntries()

            CoroutineScope(Dispatchers.Main).launch {
                adapter.updateData(updated)
            }
        }
    }

    private fun viewEntry(entry: DiaryEntry) {
        val dialog = android.app.AlertDialog.Builder(requireContext())
            .setTitle("Diary Entry")
            .setMessage("Date: ${entry.date}\n\n${entry.text}")
            .setPositiveButton("Close", null)
            .setNegativeButton("Edit") { _, _ ->
                editEntry(entry)
            }
            .create()

        dialog.show()
    }

    private fun editEntry(entry: DiaryEntry) {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_edit_entry, null)

        val editText = dialogView.findViewById<EditText>(R.id.editEntryText)
        editText.setText(entry.text)

        val dialog = android.app.AlertDialog.Builder(requireContext())
            .setTitle("Edit Entry")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newText = editText.text.toString()

                CoroutineScope(Dispatchers.IO).launch {
                    db.diaryDao().update(
                        DiaryEntry(
                            id = entry.id,
                            date = entry.date,
                            text = newText
                        )
                    )

                    val updatedList = db.diaryDao().getAllEntries()

                    CoroutineScope(Dispatchers.Main).launch {
                        adapter.updateData(updatedList)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }
}
