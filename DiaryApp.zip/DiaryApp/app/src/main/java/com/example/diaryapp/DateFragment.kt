package com.example.diaryapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider

class DateFragment : Fragment() {

    private lateinit var viewModel: SharedViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_date, container, false)

        viewModel = ViewModelProvider(requireActivity())[SharedViewModel::class.java]

        val datePicker = view.findViewById<DatePicker>(R.id.datePicker)

        // When user changes the date
        datePicker.setOnDateChangedListener { _, year, month, day ->
            val selectedDate = "$day/${month + 1}/$year"
            viewModel.selectedDate.value = selectedDate
        }

        return view
    }
}
